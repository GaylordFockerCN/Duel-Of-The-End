package com.gaboj1.tcr.worldgen.tf;

public interface Context {
    int nextRandom(int limit);
}